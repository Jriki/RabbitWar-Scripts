using System.Collections;
using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public float multiplier = 2f;
    public float speedMultiplier = 2f;
    public float duration = 5f;

    public GameObject pickupEffect;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<PlayerController>())
        {
            StartCoroutine(Pickup(other));
        }
    }

    IEnumerator Pickup(Collider2D player)
    {
        Instantiate(pickupEffect, transform.position, transform.rotation);

        PlayerController stats = player.GetComponent<PlayerController>();
        PlayerMovement speedStat = player.GetComponent<PlayerMovement>();
        stats.maxHealth *= multiplier;
        stats.currentHealth *= multiplier;
        speedStat.runSpeed *= speedMultiplier;

        GetComponent<SpriteRenderer>().enabled = false;
        GetComponent<Collider2D>().enabled = false;

        yield return new WaitForSeconds(duration);

        speedStat.runSpeed /= speedMultiplier;

        Destroy(gameObject);
    }
}